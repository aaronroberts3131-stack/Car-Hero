// Small script for year and basic UX
document.getElementById('year').textContent = new Date().getFullYear();
